<script setup>
import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue'
</script>

<template>
    <div id="app">
    <div class="container">

      <!--Sidebar-->
      <aside class="sidebar">
        <h1>XYZ RAILWAY</h1>
        <ul>
          <li>Dashboard</li>
          <li>User Management</li>
          <li>Railway Line Management</li>
        </ul>
      </aside>

        <hr />
      <!--Main Content-->
      <main class="content">

         <!-- User Display (Top Bar) -->
         <div class="top-bar">
          <div class="user-display">
            <img src="https://via.placeholder.com/30" alt="User Icon" class="user-icon" />
            <span class="username">Suraya Azman</span>
            <span class="dropdown-icon">▼</span>
          </div>
        </div>

        <hr />
        <header class="header">
          <h2>Railway Management</h2>
          <button class="create-button">Create New Railway</button>
        </header>
      
      <!--Table-->
      <table class="railway-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Status</th>
            <th>Created On</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Nurfarisha Kamarrudin</td>
            <td>In Process</td>
            <td>02/12/2024</td>
            <td>
              <button class="edit-button">Edit</button>
              <button class="delete-button">Delete</button>
            </td>
          </tr>
          <tr>
            <td>Aliyah Balqis Kamarul</td>
            <td>In Process</td>
            <td>18/10/2024</td>
            <td>
              <button class="edit-button">Edit</button>
              <button class="delete-button">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
      </main>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style scoped>

/* Container */
.container {
  display: flex;
  height: 100vh;
}

/* Sidebar */
.sidebar {
  width: 100%;
  background-color: #f4f4f4;
  padding: 20px;
  box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
  box-align: center;
}

.sidebar h1 {
  margin-bottom: 20px;
  font-size: 18px;
}

.sidebar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar li {
  background-color: #ffffff; 
  border: 1px solid #ddd; 
  
  padding: 10px 15px;
  margin-bottom: 0px; 
  text-align: center;
  font-size: 16px; 
  font-weight: bold; 
  
  cursor: pointer; 
  transition: background-color 0.3s, box-shadow 0.3s;
}

.sidebar li:hover {
  background-color: #007bff; 
  color: #ffffff; 
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

/* Main Content */
.content {
  flex: 1;
  padding: 20px;
}

/* Top Bar */
.top-bar {
  display: flex;
  justify-content: flex-end;
  width: 100%;
  
  align-items: center;
  padding: 10px 15px;
  background-color: #f4f4f4;
  border-bottom: none;
  box-shadow: none;
}


.user-display {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-right: 20px;  
  
}

.user-icon {
  width: 30px;
  height: 30px;
  border-radius: 50%;
}

.username {
  font-size: 16px;
  font-weight: bold;
  color: #333;
}

.dropdown-icon {
  font-size: 14px;
  color: #333;
  cursor: pointer;
}

/* Header */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 280%;
}

.create-button {
  background-color: black;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  
  margin-right: 10px;
}

.create-button:hover {
  background-color: #007bff;
}

/* Table */
.railway-table {
  width: 280%;
  border-collapse: collapse;
  text-align: left; 
  margin-top: 20px;
 
}

.railway-table th,
.railway-table td {
  padding: 10px;
  border: 1px solid #ddd;
  vertical-align: middle;
}

.railway-table th {
  background-color: #f4f4f4;
  font-weight: bold;
  text-align: center;
}

.railway-table td {
  text-align: center;
}

.railway-table tbody tr {
  transition: background-color 0.3s;
}

.railway-table tbody tr:hover {
  background-color: #f9f9f9; 
}


.edit-button,
.delete-button {
  background-color: black;
  color: white;
  font-size: 12px;
  padding: 5px 10px;
  margin-right: 5px;
  border: none;
  border-radius: 5px;
}

.edit-button:hover,
.delete-button:hover {
  background-color: #d32f2f;
}

body {
  font-family: 'Arial', sans-serif;
  background-color: #f9f9f9; 
  color: #333; 
}

h1, h2 {
  font-weight: bold;
}

@media (max-width: 768px) {
  .sidebar {
    width: 100%; /* Full width on small screens */
    padding: 10px;
  }
  .sidebar li {
    text-align: left; 
  }
}

</style>
